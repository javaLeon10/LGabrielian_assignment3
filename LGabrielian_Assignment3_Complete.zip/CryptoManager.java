 
/* Leon Gabrielian, Class CMSC203	
Class: CMSC203 
		Instructor: Professor Elvazi
		Description:  A program that decrypts then encrypts a word using the bellaso and caesar ciphers.

               Due: 7/14/2022\
		Platform/compiler: Windows,java version \"18.0.1.1\" 2022-04-22
		Java(TM) SE Runtime Environment (build 18.0.1.1+2-6)
		Java HotSpot(TM) 64-Bit Server VM (build 18.0.1.1+2-6, mixed mode,sharing
		I pledge that I have completed the programming assignment independently.
	 I have not copied the code from a student or any source.
		 I have not given my code to any student.
	 Print your Name here: Leon Gabrielian "*/



package application;

public class CryptoManager {
	
	private static final char LOWER_BOUND = 32;
	private static final char UPPER_BOUND = 95;
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	public static boolean stringInBounds (String plainText) {
		//throw new RuntimeException("method not implemented");
		boolean res = true;
		char [] c = plainText.toCharArray();
		for (int i=0; i < c.length; i++) {
			if ((c[i] < LOWER_BOUND) || (c[i] > UPPER_BOUND)) {
				res = false;
			}
		}
		return res;
	}
	
		
		

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	public static String encryptCaesar(String plainText, int key) {
		//throw new RuntimeException("method not implemented");
		String enc = "";
		char [] c = plainText.toCharArray();
		 for (int i =0; i < c.length; i++) {
			 if (c[i] > UPPER_BOUND) { 
				 enc += (char) (c[i] + key - RANGE);
			 } else {
				 enc  += (char)  (c[i] + key);
			 }
		 }
	return enc;
	}
		
		
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	public static String encryptBellaso(String plainText, String bellasoStr) {
		//throw new RuntimeException("method not implemented");
		String enc = "";
		int l1 = bellasoStr.length();
		int l2 = plainText.length();
		
		char [] c = plainText.toCharArray();
		char [] b = bellasoStr.toCharArray();
		
		int index1 = 0;
		 for (int i =0; i < c.length; i++) {
			
			 if ((char)(c[i] + b[index1]) > UPPER_BOUND) {
			 enc += (char) (c[i] + b[index1] - RANGE);
			 } else {
				 enc+= (char) (c[i] + b[index1] );
			 }
			 System.out.println(i + " " +index1 +"  "+enc);
			 
			 if (++index1 >= l1 ) {
				 index1 = 0;
			 }
			 
			 
		 }
	return enc;	
		
	}
	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	public static String decryptCaesar(String encryptedText, int key) {
		//throw new RuntimeException("method not implemented");
		String dec = "";
		char [] c = encryptedText.toCharArray();
		 for (int i =0; i < c.length; i++) {
			 if ((char)(c[i]-key) < LOWER_BOUND) {
				 dec += (char)(c[i]-key+RANGE);
			 } else {
			 dec += (char)(c[i]-key);
			 }
		 }
	return dec;
	}
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	public static String decryptBellaso(String encryptedText, String bellasoStr) {
		//throw new RuntimeException("method not implemented");
		String dec = "";
		int l1 = bellasoStr.length();
		int l2 = encryptedText.length();
		
		char [] c = encryptedText.toCharArray();
		char [] b = bellasoStr.toCharArray();
		
		int index1 = 0;
		 for (int i =0; i < c.length; i++) {
			
			 if ((char)(c[i] - b[index1]) < LOWER_BOUND) {
				 dec += (char)(c[i]-b[index1]+RANGE);
			 } else {
			 
			 dec += (char) (c[i] - b[index1]);
			 }
			 
			 if (++index1 == l1 ) {
				 index1 = 0;
				 }
			 
			 
			 
			 
		 }
	return dec;	
	}
}
