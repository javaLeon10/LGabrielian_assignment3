package application;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitAssignmentTest1 {

@Test
public void test() {
//fail("Not yet implemented");
CryptoManager sib = new CryptoManager();
boolean r1 = sib.stringInBounds("J@va");
boolean r2 = sib.stringInBounds("LEON");

int i=0;

if (r1 == false) {
i = 1;
} else {
i=2;
}
int ii = 0;

if (r2 == false) {
ii = 1;
} else {
ii=2;
}

assertEquals(i,1);
assertEquals(ii,2);

}
}
